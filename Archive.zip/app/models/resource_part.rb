class ResourcePart < ApplicationRecord
  belongs_to :resource
  belongs_to :part

end
