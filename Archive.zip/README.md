# pocket_ramiro_rails

## Description
```
```
## Contibutors
```
Carrie Walsh(https://github.com/carriewalsh)
Michael King-Stockton(https://github.com/KStockton)
Ryan D Barnett(https://github.com/RyanDBarnett)
Jennica Stiehl(https://github.com/stiehlrod)
```
